function dydt = Second_ODE(t,y,u)
  dydt = u;